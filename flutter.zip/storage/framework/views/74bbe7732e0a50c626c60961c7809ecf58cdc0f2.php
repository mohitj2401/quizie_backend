   
   <?php $__env->startSection('style'); ?>
       <style>
           .dropdown-item>svg {
               margin-right: 10px;
           }

       </style>
   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('content'); ?>

       <main>
           <div class="container-fluid mt-5">


               <div class="card mb-4">
                   <div class="card-header">
                       <i class="fas fa-table mr-1"></i>
                       Results for <?php echo e($name); ?>


                   </div>
                   <div class="card-body">
                       <div class="table-responsive">
                           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                               <thead>
                                   <tr>
                                       <th>Student Name</th>
                                       <th>Quiz Title</th>

                                       <th>Total</th>
                                       <th>Incorrect</th>
                                       <th>Correct</th>
                                       <th>Not Attempted</th>
                                       <th>Action</th>

                                   </tr>
                               </thead>

                               <tbody>
                                   <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td><?php echo e($result->user->name); ?></td>
                                           <td><?php echo e($result->quiz->title); ?></td>
                                           <td><?php echo e($result->total); ?></td>
                                           <td><?php echo e($result->incorrect); ?></td>
                                           <td><?php echo e($result->correct); ?></td>
                                           <td><?php echo e($result->notAttempted); ?></td>
                                           <td>
                                               <a href="<?php echo e(route('download.results', ['user' => $result->user->id, 'quiz' => $result->quiz->id])); ?>"
                                                   class="btn btn-success">Download Results</a>
                                               

                                           </td>
                                       </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>

           </div>
       </main>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flutter\resources\views/admin/results.blade.php ENDPATH**/ ?>