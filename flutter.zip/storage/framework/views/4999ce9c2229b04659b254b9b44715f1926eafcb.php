   
   <?php $__env->startSection('style'); ?>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-toggle/2.2.2/css/bootstrap-toggle.css">
       <style>
           .dropdown-item>svg {
               margin-right: 10px;
           }

           .toggle-off.btn {
               padding-left: 0px !important;
           }

           .toggle-on.btn {
               padding-right: 0px !important;
           }

       </style>
   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('content'); ?>

       <main>
           <div class="container-fluid mt-5">


               <div class="card mb-4">
                   <div class="card-header">
                       <i class="fas fa-table mr-1"></i>
                       User List
                       <a data-toggle="modal" data-target="#Import" href=""><i class="fas fa-plus-circle"
                               style="float: right;
                                                                                                                                                                                                                                                                                                                                                                                font-size: 23px;
                                                                                                                                                                                                                                                                                                                                                                                "></i></a>
                   </div>
                   <div class="card-body">
                       <div class="table-responsive">
                           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                               <thead>
                                   <tr>
                                       <th>Name</th>


                                       <th>Email</th>

                                       <th>Status</th>
                                       <th>Created At</th>
                                       <th>Action</th>

                                   </tr>
                               </thead>

                               <tbody>
                                   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td><?php echo e($user->name); ?></td>
                                           <td><?php echo e($user->email); ?></td>
                                           <td> <input type="checkbox" class="userStatus" rel="<?php echo e($user->id); ?>"
                                                   data-toggle="toggle" data-onstyle="success" data-offstyle="danger" <?php if($user->status == 1): ?> checked <?php endif; ?>>
                                           </td>

                                           <td><?php echo e($user->created_at); ?></td>

                                           <td>

                                               <div class="dropdown">
                                                   <a type="button" id="dropdownMenuButton" data-toggle="dropdown">
                                                       <i class="fas fa-ellipsis-v"></i>
                                                   </a>
                                                   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                       <a class="dropdown-item"
                                                           href="<?php echo e(route('teacher.edit.subject', $user->id)); ?>"><i
                                                               class="fas fa-pencil-alt"></i>Edit</a>
                                                       <a class="dropdown-item"
                                                           href="<?php echo e(route('user.delete', $user->id)); ?>"><i
                                                               class="fas fa-trash"></i>Delete</a>
                                                   </div>
                                               </div>

                                           </td>
                                       </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>

           </div>
       </main>
   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('scripts'); ?>

       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-toggle/2.2.2/js/bootstrap2-toggle.js"></script>

       <script>
           $('.userStatus').change(function() {

               var id = $(this).attr('rel');
               var token = '<?php echo e(csrf_token()); ?>';
               var url = "<?php echo e(url('/user/approve')); ?>";
               if ($(this).prop('checked') == true) {
                   $.ajax({

                       type: 'post',
                       url: url,
                       data: {
                           status: '1',
                           id: id,
                           _token: token
                       },
                       success: function(data) {


                       },
                       error: function(res) {

                           alert('Something Went Wrong Please Try Again!');
                       }

                   });
               } else {
                   $.ajax({
                       type: 'post',
                       url: url,
                       data: {
                           status: '0',
                           id: id,
                           _token: token
                       },
                       success: function(resp) {




                       },
                       error: function(err) {
                           alert('Something Went Wrong Please Try Again!');
                       }

                   })
               }
           });

       </script>
   <?php $__env->stopSection(); ?>
   <?php if(auth()->user()->usertype_id == 1): ?>
       <?php echo $__env->make('commons.modal',array('from_title'=>'Teacher
       Create','route'=>'/user/create','file_name'=>'user_sample'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php else: ?>
       <?php echo $__env->make('commons.modal',array('from_title'=>'Student
       Create','route'=>'/user/create','file_name'=>'user_sample'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php endif; ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flutter\resources\views/user/list.blade.php ENDPATH**/ ?>