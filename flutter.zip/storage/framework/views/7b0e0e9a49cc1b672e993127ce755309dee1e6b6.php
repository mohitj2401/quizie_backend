   
   <?php $__env->startSection('style'); ?>
       <style>
           .dropdown-item>svg {
               margin-right: 10px;
           }

       </style>
   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('content'); ?>

       <main>
           <div class="container-fluid mt-5">


               <div class="card mb-4">
                   <div class="card-header">
                       <i class="fas fa-table mr-1"></i>
                       Subjects
                       <a data-toggle="modal" data-target="#exampleModal" href=""><i class="fas fa-plus-circle"
                               style="float: right;
                                                                                                                                                                            font-size: 23px;
                                                                                                                                                                            "></i></a>
                   </div>
                   <div class="card-body">
                       <div class="table-responsive">
                           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                               <thead>
                                   <tr>
                                       <th>Name</th>
                                       <th>Code</th>
                                       <th>Created By</th>
                                       <th>Total Quiz</th>
                                       <th>Status</th>
                                       <th>Action</th>

                                   </tr>
                               </thead>

                               <tbody>
                                   <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td><?php echo e($subject->name); ?></td>
                                           <td><?php echo e($subject->code); ?></td>
                                           <td><?php echo e($subject->user->name); ?></td>

                                           <td><?php echo e($subject->quiz()->count()); ?></td>
                                           <td><?php echo e($subject->status == 1 ? 'Active' : 'Deactive'); ?></td>
                                           <td>
                                               <?php if($subject->user->id == auth()->user()->id): ?>
                                                   <div class="dropdown">
                                                       <a type="button" id="dropdownMenuButton" data-toggle="dropdown">
                                                           <i class="fas fa-ellipsis-v"></i>
                                                       </a>
                                                       <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                           <a class="dropdown-item"
                                                               href="<?php echo e(route('teacher.edit.subject', $subject->id)); ?>"><i
                                                                   class="fas fa-pencil-alt"></i>Edit</a>
                                                           <a class="dropdown-item"
                                                               href="<?php echo e(route('subject.delete', $subject->id)); ?>"><i
                                                                   class="fas fa-trash"></i>Delete</a>
                                                       </div>
                                                   </div>
                                               <?php else: ?>
                                                   Not Allowed
                                               <?php endif; ?>
                                           </td>
                                       </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>

           </div>
       </main>
   <?php $__env->stopSection(); ?>

   <?php echo $__env->make('commons.modal',array('from_title'=>'Subject
   Create','route'=>'/create/subject','file_name'=>'subject_sample'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flutter\resources\views/subject/list.blade.php ENDPATH**/ ?>