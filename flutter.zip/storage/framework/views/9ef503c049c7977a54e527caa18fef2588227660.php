<?php $__env->startSection('style'); ?>
    <style>
        .mt-10 {
            margin-top: 10px;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('quiz_id')): ?>
        <?php $quiz_id = Session::get('quiz_id'); ?>
    <?php else: ?>
        <?php $quiz_id = ''; ?>
    <?php endif; ?>
    <main>
        <div class="container" style="margin-top: 20px;">
            <div class="card">
                <div class="card-header"><?php echo e(__('Create Question')); ?>

                    <a class="btn  btn-sm btn-primary" style="float: right"
                        href="<?php echo e(asset('assets/excels/sample.xlsx')); ?>">
                        Download Sample file
                    </a>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('create.question')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label class="col-md-3 col-form-label "><?php echo e(__('Quiz')); ?></label>

                            <div class="col-md-8">
                                <select name="quiz" id="quiz" class="form-control <?php $__errorArgs = ['quiz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required>
                                    <option value="">Select Quiz</option>
                                    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($quiz->id); ?>" <?php if($quiz_id == $quiz->id): ?> selected <?php endif; ?>>
                                            <?php echo e($quiz->title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['quiz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"><?php echo e(__('Excel File')); ?></label>

                            <div class="col-md-8">
                                <input type="file" class="form-control <?php $__errorArgs = ['excel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="excel"
                                    required>

                                <?php $__errorArgs = ['excel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Create Question')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card mb-4 mt-10">
                <div class="card-header">
                    <i class="fas fa-table mr-1"></i>
                    Questions for <span id="selectedquiz"></span>

                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Question</th>
                                    <th>Option 1(Currect option)</th>
                                    <th>Option 2</th>
                                    <th>Option 3</th>
                                    <th>Option 4</th>

                                    <th>Action</th>

                                </tr>
                            </thead>

                            <tbody id="tableBody">



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php if($quiz_id): ?>

        <script>
            $(document).ready(function() {
                $('#selectedquiz').empty();
                url = "<?php echo e(url('/get/questions/')); ?>" + '/' + "<?php echo e($quiz_id); ?>";
                $('#selectedquiz').append($('#quiz option:selected').text());

                $.ajax({
                    type: "get",
                    url: url,
                    success: function(response) {

                        $('#tableBody').empty();
                        var len = 0;


                        if (response['data'] != null) {
                            len = response['data'].length;
                        }

                        if (len > 0) {
                            // Read data and create <option >
                            for (var i = 0; i < len; i++) {

                                var title = response['data'][i].title;
                                var id = response['data'][i].id;
                                var option1 = response['data'][i].option1;
                                var option2 = response['data'][i].option2;
                                var option3 = response['data'][i].option3;
                                var option4 = response['data'][i].option4;
                                var route = "<?php echo e(url('/question/delete/')); ?>" + '/' + id + '/' +
                                    response[
                                        'data'][i].quiz_id;
                                var option =
                                    '<tr><td>' + title + '</td><td>' + option1 + '</td><td>' + option2 +
                                    '</td><td>' + option3 +
                                    '</td><td>' + option4 +
                                    '</td><td><a class="btn btn-danger" href="' + route +
                                    '"><i class="fas fa-trash"></i></a></td></tr>';
                                $('#tableBody').append(option);
                            }
                        }
                    },
                    error: function(response) {
                        console.log('Something Went Worng Please Try Again!');
                    }
                });
            });

        </script>
    <?php endif; ?>
    <script>
        $("#quiz").change(function() {
            $('#selectedquiz').empty();
            url = "<?php echo e(url('/get/questions/')); ?>" + '/' + $(this).val();
            $('#selectedquiz').append($('#quiz option:selected').text());

            $.ajax({
                type: "get",
                url: url,
                success: function(response) {

                    $('#tableBody').empty();
                    var len = 0;


                    if (response['data'] != null) {
                        len = response['data'].length;
                    }

                    if (len > 0) {
                        // Read data and create <option >
                        for (var i = 0; i < len; i++) {

                            var title = response['data'][i].title;
                            var id = response['data'][i].id;
                            var option1 = response['data'][i].option1;
                            var option2 = response['data'][i].option2;
                            var option3 = response['data'][i].option3;
                            var option4 = response['data'][i].option4;
                            var route = "<?php echo e(url('/question/delete/')); ?>" + '/' + id + '/' + response[
                                'data'][i].quiz_id;
                            var option =
                                '<tr><td>' + title + '</td><td>' + option1 + '</td><td>' + option2 +
                                '</td><td>' + option3 +
                                '</td><td>' + option4 +
                                '</td><td><a class="btn btn-danger" href="' + route +
                                '"><i class="fas fa-trash"></i></a></td></tr>';
                            $('#tableBody').append(option);
                        }
                    }
                },
                error: function(response) {
                    console.log('Something Went Worng Please Try Again!');
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\flutter\resources\views/admin/questioncreate.blade.php ENDPATH**/ ?>